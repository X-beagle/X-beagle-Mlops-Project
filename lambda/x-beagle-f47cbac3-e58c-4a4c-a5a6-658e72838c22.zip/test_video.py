import boto3
import base64
import json
import cv2
import numpy as np

sagemaker_runtime = boto3.client('sagemaker-runtime')
kinesis_client = boto3.client('kinesisvideo')
kinesis_data_client = boto3.client('kinesis-video-media')

def lambda_handler(event, context):
    endpoint_name = 'x-beagle-deployModel-1716535283133-Endpoint-20240524-072712'
    stream_name = 'x-beagle_rtVideo'
    
    try:
        # 예제 이미지 데이터 (여기서는 예제로 base64로 인코딩된 이미지 사용)
        # 실제 사용 시에는 이미지 데이터를 받아와서 사용해야 함
        input_image_data = event['image']  # 'image' 키로 base64 인코딩된 이미지 데이터를 받아온다고 가정

        # SageMaker 엔드포인트로 요청 보내기
        response = sagemaker_runtime.invoke_endpoint(
            EndpointName=endpoint_name,
            ContentType='application/x-image',
            Body=base64.b64decode(input_image_data)
        )

        # 엔드포인트 응답 처리
        result = json.loads(response['Body'].read().decode())
        
        # Kinesis Video Streams에 스트리밍할 데이터 준비
        data = {
            'image': input_image_data,
            'detections': result['detections']
        }
        payload = json.dumps(data).encode('utf-8')
        
        # Kinesis Video Streams에 전송
        kinesis_data_client.put_media(
            StreamName=stream_name,
            Payload=payload,
            Timestamp=None,
            FragmentNumber=None
        )
        
        return {
            'statusCode': 200,
            'body': 'Successfully streamed results to Kinesis Video Streams'
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': str(e)
        }
