import boto3
import json

def lambda_handler(event, context):
    # S3 버킷 이름과 동영상 파일 이름을 설정합니다.
    bucket = "x-beagle"  # 버킷 이름을 하드코딩합니다.
    key = "video/test1.mp4"  # 동영상 파일의 경로를 설정합니다.

    # S3 객체의 URL을 생성합니다.
    region = "ap-northeast-2"  # S3 버킷의 리전입니다.
    url = f"https://{bucket}.s3.{region}.amazonaws.com/{key}"

    # URL을 반환합니다.
    return {
        'statusCode': 200,
        'body': json.dumps({'url': url})
    }
