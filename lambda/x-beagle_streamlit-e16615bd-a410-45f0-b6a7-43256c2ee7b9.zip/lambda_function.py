import json
import boto3

def lambda_handler(event, context):
    # SageMaker 엔드포인트의 URL
    endpoint_name = 'x-beagle-endpoint'
    runtime = boto3.client('runtime.sagemaker')

    # SageMaker 엔드포인트에 요청을 보냄
    response = runtime.invoke_endpoint(EndpointName=endpoint_name, ContentType='application/json', Body=json.dumps(event))

    # 결과 가져오기
    result = response['Body'].read().decode()

    return {
        'statusCode': 200,
        'body': result
    }

