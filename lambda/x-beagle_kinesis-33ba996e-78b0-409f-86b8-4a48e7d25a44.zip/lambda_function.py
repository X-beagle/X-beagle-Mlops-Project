from __future__ import print_function
import base64
import json
import boto3
import os
import datetime
import time
from botocore.exceptions import ClientError

bucket='arn:aws:s3:::x-beagle'

#Lambda 함수는 Amazon SageMaker 예제의 출력을 기반으로 작성되었습니다. 
#https://github.com/awslabs/amazon-sagemaker-examples/blob/master/introduction_to_amazon_algorithms/object_detection_pascalvoc_coco/object_detection_image_json_format.ipynb
object_categories = { 0: 'Hammer', 1: 'SSD', 2: 'Alcohol', 3: 'Spanner', 4: 'Axe', 5: 'Awl', 6: 'Throwing Knife', 7: 'Firecracker',
                    8: 'Thinner', 9: 'Plier', 10: 'Match', 11: 'Smart Phone', 12: 'Scissors', 13: 'Tablet PC', 14: 'Solid Fuel',
                    15: 'Bat', 16: 'Portable Gas', 17: 'Nail Clippers', 18: 'Knife', 19: 'Metal Pipe',
                    20: 'Electronic Cigarettes(Liquid)', 21: 'Supplymentary Battery', 22: 'Bullet', 23: 'Gun Parts', 24: 'USB',
                    25: 'Liquid', 26: 'Aerosol', 27: 'Screwdriver', 28: 'Chisel', 29: 'Handcuffs', 30: 'Lighter', 31: 'HDD',
                    32: 'Electronic Cigarettes', 33: 'Battery', 34: 'Gun', 35: 'Laptop', 36: 'Saw', 37: 'Zippo Oil', 38: 'Stun Gun',
                    39: 'Camera', 40: 'Camcorder', 41: 'SD Card'
}

def lambda_handler(event, context):
  for record in event['Records']:
    payload = base64.b64decode(record['kinesis']['data'])
    #Kinesis Data Stream 출력의 Json 형식 가져오기
    result = json.loads(payload)
    #FragmentMetaData 가져오기
    fragment = result['fragmentMetaData']
    
    # Fragment ID 및 Timestamp 추출
    frag_id = fragment[17:-1].split(",")[0].split("=")[1]
    srv_ts = datetime.datetime.fromtimestamp(float(fragment[17:-1].split(",")[1].split("=")[1])/1000)
    srv_ts1 = srv_ts.strftime("%A, %d %B %Y %H:%M:%S")
    
    #FrameMetaData 가져오기
    frame = result['frameMetaData']
    #StreamName 가져오기
    streamName = result['streamName']
   
    #Json 형식의 SageMaker 응답
    sageMakerOutput = json.loads(base64.b64decode(result['sageMakerOutput']))
    #확률이 가장 높은 5개 탐지된 객체 인쇄
    for i in range(5):
      print("detected object: " + object_categories[int(sageMakerOutput['prediction'][i][0])] + ", with probability: " + str(sageMakerOutput['prediction'][i][1]))
    
    detections={}
    detections['StreamName']=streamName
    detections['fragmentMetaData']=fragment
    detections['frameMetaData']=frame
    detections['sageMakerOutput']=sageMakerOutput

    #KVS fragment를 가져오고 .webm 파일 및 탐지 세부 정보를 S3에 작성
    s3 = boto3.client('s3')
    kv = boto3.client('kinesisvideo')
    get_ep = kv.get_data_endpoint(StreamName=streamName, APIName='GET_MEDIA_FOR_FRAGMENT_LIST')
    kvam_ep = get_ep['DataEndpoint']
    kvam = boto3.client('kinesis-video-archived-media', endpoint_url=kvam_ep)
    getmedia = kvam.get_media_for_fragment_list(
                            StreamName=streamName,
                            Fragments=[frag_id])
    base_key=streamName+"_"+time.strftime("%Y%m%d-%H%M%S")
    webm_key=base_key+'.webm'
    text_key=base_key+'.txt'
    s3.put_object(Bucket=bucket, Key=webm_key, Body=getmedia['Payload'].read())
    s3.put_object(Bucket=bucket, Key=text_key, Body=json.dumps(detections))
    print("Detection details and fragment stored in the S3 bucket "+bucket+" with object names : "+webm_key+" & "+text_key)
  return 'Successfully processed {} records.'.format(len(event['Records']))