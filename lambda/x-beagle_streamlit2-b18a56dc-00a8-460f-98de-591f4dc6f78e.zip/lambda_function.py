import json
import boto3
import requests

def lambda_handler(event, context):
    # 세이지메이커 엔드포인트 URL
    endpoint_url = f"https://runtime.sagemaker.ap-northeast-2.amazonaws.com/endpoints/xbeagle-yolov8-2024-05-23-16-45-46-104355/invocations"
    
    try:
        # 엔드포인트에 POST 요청 보내기
        response = requests.post(endpoint_url)
        
        # 요청이 성공한 경우
        if response.status_code == 200:
            prediction = response.json()
            return {
                "statusCode": 200,
                "body": json.dumps(prediction)
            }
        # 요청이 실패한 경우
        else:
            return {
                "statusCode": response.status_code,
                "body": "Prediction request failed"
            }
    except Exception as e:
        return {
            "statusCode": 500,
            "body": str(e)
        }
